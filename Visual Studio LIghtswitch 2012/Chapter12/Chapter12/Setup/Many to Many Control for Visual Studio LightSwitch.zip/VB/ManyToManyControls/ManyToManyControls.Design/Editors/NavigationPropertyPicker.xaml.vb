﻿Imports System.ComponentModel.Composition
Imports System.Windows.Markup
Imports System.Windows

Imports Microsoft.LightSwitch.Designers.PropertyPages
Imports Microsoft.LightSwitch.Designers.PropertyPages.UI
Imports System.Windows.Controls
Imports Microsoft.LightSwitch.Designers.ScreenDesigner.Definition.PropertyPages
Imports Microsoft.LightSwitch.Designers.ScreenDesigner.Definition.DesignerModels
Imports Microsoft.LightSwitch.Model
Imports Microsoft.LightSwitch.Designers.PropertyPages.ViewModel

Public Class NavigationPropertyPicker
    Inherits UserControl

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    End Sub


    Private Sub ComboBox_SelectionChanged(sender As Object, e As System.Windows.Controls.SelectionChangedEventArgs) Handles ComboBox.SelectionChanged

        'Want to update the choices property if the targetNavProperty changes to something else that doesn't match its datatype
        Dim targetNavPropertyName As String = ComboBox.SelectedItem
        Dim entry As IBindablePropertyEntry = TryCast(DataContext, IBindablePropertyEntry)

        If entry IsNot Nothing Then
            Dim propertyValue As IContentItemControlSpecificPropertyValue = entry.Entry.PropertyValue
            Dim contentItem As IContentItemDesignerViewModel = propertyValue.ContentItem

            If TypeOf entry.Entry.PropertyValue.ModelItem Is IContentItemDefinition Then
                Dim screenDef As IScreenDefinition = ModelUtilities.GetScreenFromContentItemDefinition(entry.Entry.PropertyValue.ModelItem)
                If screenDef.Members.OfType(Of IScreenCollectionPropertyDefinition).Where(Function(m) m.Name = contentItem.BindingString).SingleOrDefault IsNot Nothing Then
                    Dim screenCollectionDef As IScreenCollectionPropertyDefinition = screenDef.Members.Where(Function(m) m.Name = contentItem.BindingString).SingleOrDefault()
                    Dim sourceNavProperty As INavigationPropertyDefinition = ModelUtilities.GetSourceNavProperty(screenCollectionDef)

                    If sourceNavProperty IsNot Nothing Then
                        Dim targetNavProperty As INavigationPropertyDefinition = ModelUtilities.GetTargetNavProperty(DirectCast(contentItem.DataType, ISequenceType).ElementType, targetNavPropertyName, sourceNavProperty)

                        If targetNavProperty IsNot Nothing Then
                            'Need to reset the choices collection if its type doesn't match the target nav property
                            Dim choiceCollectionProperty As IScreenDesignerPropertyEntry = contentItem.PropertyEntries.Where(Function(p) p.PropertyName.Contains("ChoicesCollection")).SingleOrDefault
                            If choiceCollectionProperty IsNot Nothing Then
                                Dim choiceCollectionName As String = choiceCollectionProperty.PropertyValue.Value
                                If Not String.IsNullOrWhiteSpace(choiceCollectionName) Then
                                    Dim choiceCollection As IScreenCollectionPropertyDefinition = screenDef.Members.Where(Function(m) m.Name = choiceCollectionName).SingleOrDefault
                                    If choiceCollection Is Nothing Then
                                        choiceCollectionProperty.PropertyValue.Value = ""
                                    Else
                                        If Not DirectCast(choiceCollection.PropertyType, ISequenceType).ElementType Is targetNavProperty.ElementType Then
                                            choiceCollectionProperty.PropertyValue.Value = ""
                                        End If
                                    End If
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        End If

        'Microsoft.LightSwitch.Designers.ScreenDesigner.Definition.PropertyPages.IContentItemControlSpecificPropertyValue
    End Sub
End Class

<Export(GetType(IPropertyValueEditorProvider))>
<PropertyValueEditorName("ManyToManyControls:NavigationPropertyPicker")>
<PropertyValueEditorType("System.String")>
Public Class NavigationPropertyPickerEditor
    Implements IPropertyValueEditorProvider

    Public Function GetEditor(entry As Microsoft.LightSwitch.Designers.PropertyPages.IPropertyEntry) As Microsoft.LightSwitch.Designers.PropertyPages.UI.IPropertyValueEditor Implements Microsoft.LightSwitch.Designers.PropertyPages.UI.IPropertyValueEditorProvider.GetEditor
        Return New Editor()
    End Function

    Private Class Editor
        Implements IPropertyValueEditor

        Public ReadOnly Property Context As Object Implements Microsoft.LightSwitch.Designers.PropertyPages.UI.IPropertyValueEditor.Context
            Get
                ' A design-time editor allows an additional Context object, which is exposed through IBindablePropertyEntry.EditorContext.  This allows the editor to have additional status.
                ' However, the run-time designer does not support it.  It is not used in this sample.
                Return Nothing
            End Get
        End Property

        ' The DataTemplate is used by the screen designer to create the UI control on the property sheet.
        Public Function GetEditorTemplate(entry As Microsoft.LightSwitch.Designers.PropertyPages.IPropertyEntry) As System.Windows.DataTemplate Implements Microsoft.LightSwitch.Designers.PropertyPages.UI.IPropertyValueEditor.GetEditorTemplate
            Return XamlReader.Parse(NavigationPropertyPickerEditor.ControlTemplate)
        End Function

    End Class

#Region "Constants"

    Private Const ControlTemplate As String =
        "<DataTemplate" +
        " xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""" +
        " xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""" +
        " xmlns:editors=""clr-namespace:ManyToManyControls;assembly=ManyToManyControls.Design"">" +
        "   <editors:NavigationPropertyPicker/>" +
        "</DataTemplate>"

#End Region
End Class
