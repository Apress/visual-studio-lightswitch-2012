﻿Imports Microsoft.LightSwitch.Designers.PropertyPages
Imports Microsoft.LightSwitch.Designers.PropertyPages.UI
Imports Microsoft.LightSwitch.Designers.PropertyPages.ViewModel
Imports Microsoft.LightSwitch.Designers.ScreenDesigner.Definition.PropertyPages
Imports Microsoft.LightSwitch.Designers.ScreenDesigner.Definition.DesignerModels
Imports Microsoft.LightSwitch.Model
Imports System.ComponentModel.Composition
Imports System.Windows.Markup
Imports System.Windows



Public Class ChoicesCollectionPicker
    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
    End Sub

    Private Sub ComboBox_DropDownOpened(sender As Object, e As System.EventArgs) Handles ComboBox.DropDownOpened
        UpdateChoices()
    End Sub

    Private Sub UpdateChoices()
        

        'Want to update its contents - need to get a list of all valid members from the screen
        Dim entry As IBindablePropertyEntry = TryCast(DataContext, IBindablePropertyEntry)
        If entry IsNot Nothing Then
            Dim choicesList As List(Of String) = New List(Of String)
            choicesList.Add(String.Empty)


            Dim propertyValue As IContentItemControlSpecificPropertyValue = entry.Entry.PropertyValue
            Dim contentItem As IContentItemDesignerViewModel = propertyValue.ContentItem

            If TypeOf entry.Entry.PropertyValue.ModelItem Is IContentItemDefinition Then
                Dim screenDef As IScreenDefinition = ModelUtilities.GetScreenFromContentItemDefinition(entry.Entry.PropertyValue.ModelItem)

                If screenDef IsNot Nothing Then
                    'Get the sourceNavProperty (auto determined)
                    If screenDef.Members.OfType(Of IScreenCollectionPropertyDefinition).Where(Function(m) m.Name = contentItem.BindingString).SingleOrDefault IsNot Nothing Then
                        Dim screenCollectionDef As IScreenCollectionPropertyDefinition = screenDef.Members.Where(Function(m) m.Name = contentItem.BindingString).SingleOrDefault
                        Dim sourceNavProperty As INavigationPropertyDefinition = ModelUtilities.GetSourceNavProperty(screenCollectionDef)
                        If sourceNavProperty IsNot Nothing Then
                            'Get the name of the targetNavProperty
                            Dim targetNavPropertyName As String = Nothing
                            Dim targetNavPropertyProperty As IScreenDesignerPropertyEntry = contentItem.PropertyEntries.Where(Function(p) p.PropertyName.Contains("TargetNavigationProperty")).SingleOrDefault()
                            If targetNavPropertyProperty IsNot Nothing Then
                                targetNavPropertyName = targetNavPropertyProperty.PropertyValue.Value
                            End If

                            Dim targetNavProperty As INavigationPropertyDefinition = ModelUtilities.GetTargetNavProperty(DirectCast(contentItem.DataType, ISequenceType).ElementType, targetNavPropertyName, sourceNavProperty)

                            If targetNavProperty IsNot Nothing Then
                                'get a list of all collections that are associated with the type of the targetNavProperty
                                Dim choiceCollectionOptions As IEnumerable(Of IScreenCollectionPropertyDefinition) = screenDef.Members.OfType(Of IScreenCollectionPropertyDefinition).Where(Function(s) s.ElementType Is targetNavProperty.ElementType)
                                For Each c As IScreenCollectionPropertyDefinition In choiceCollectionOptions
                                    choicesList.Add(c.Name)
                                Next
                            End If
                        End If
                    End If
                End If
            End If

            Me.ComboBox.ItemsSource = choicesList
            'Update the binding
            Me.ComboBox.SetBinding(System.Windows.Controls.ComboBox.SelectedItemProperty, "Entry.PropertyValue.Value")
        End If

        
    End Sub

    Private Sub ChoicesCollectionPicker_DataContextChanged(sender As Object, e As System.Windows.DependencyPropertyChangedEventArgs) Handles Me.DataContextChanged
        UpdateChoices()
    End Sub
End Class

<Export(GetType(IPropertyValueEditorProvider))>
<PropertyValueEditorName("ManyToManyControls:ChoicesCollectionPicker")>
<PropertyValueEditorType("System.String")>
Public Class ChoicesCollectionPickerEditor
    Implements IPropertyValueEditorProvider

    Public Function GetEditor(entry As Microsoft.LightSwitch.Designers.PropertyPages.IPropertyEntry) As Microsoft.LightSwitch.Designers.PropertyPages.UI.IPropertyValueEditor Implements Microsoft.LightSwitch.Designers.PropertyPages.UI.IPropertyValueEditorProvider.GetEditor
        Return New Editor()
    End Function

    Private Class Editor
        Implements IPropertyValueEditor

        Public ReadOnly Property Context As Object Implements Microsoft.LightSwitch.Designers.PropertyPages.UI.IPropertyValueEditor.Context
            Get
                ' A design-time editor allows an additional Context object, which is exposed through IBindablePropertyEntry.EditorContext.  This allows the editor to have additional status.
                ' However, the run-time designer does not support it.  It is not used in this sample.
                Return Nothing
            End Get
        End Property

        ' The DataTemplate is used by the screen designer to create the UI control on the property sheet.
        Public Function GetEditorTemplate(entry As Microsoft.LightSwitch.Designers.PropertyPages.IPropertyEntry) As System.Windows.DataTemplate Implements Microsoft.LightSwitch.Designers.PropertyPages.UI.IPropertyValueEditor.GetEditorTemplate
            Return XamlReader.Parse(ChoicesCollectionPickerEditor.ControlTemplate)
        End Function

    End Class

#Region "Constants"

    Private Const ControlTemplate As String =
        "<DataTemplate" +
        " xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""" +
        " xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""" +
        " xmlns:editors=""clr-namespace:ManyToManyControls;assembly=ManyToManyControls.Design"">" +
        "   <editors:ChoicesCollectionPicker/>" +
        "</DataTemplate>"

#End Region
End Class
