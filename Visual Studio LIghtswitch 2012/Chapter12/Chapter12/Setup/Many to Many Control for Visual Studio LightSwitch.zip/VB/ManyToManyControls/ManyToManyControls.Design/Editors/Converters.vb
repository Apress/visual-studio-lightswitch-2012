﻿
Imports System
Imports System.Collections.Generic
Imports System.Windows.Data

Imports Microsoft.LightSwitch.Model
Imports System.Globalization
Imports Microsoft.LightSwitch.Designers.PropertyPages

Public Class GetNavigationPropertiesConverter
    Implements IValueConverter

    Public Function Convert(value As Object, targetType As System.Type, parameter As Object, culture As System.Globalization.CultureInfo) As Object Implements System.Windows.Data.IValueConverter.Convert

        Dim textProperties As List(Of String) = New List(Of String)()

        textProperties.Add(String.Empty)

        Dim contentItemDefinition As IContentItemDefinition = TryCast(value, IPropertyValue).ModelItem
        If contentItemDefinition IsNot Nothing Then
            If TypeOf contentItemDefinition.DataType Is ISequenceType Then
                Dim entityType As IEntityType = TryCast(DirectCast(contentItemDefinition.DataType, ISequenceType).ElementType, IEntityType)
                If entityType IsNot Nothing Then
                    For Each p As IPropertyDefinition In ModelUtilities.GetAllSingletonNavigationProperties(entityType)
                        textProperties.Add(p.Name)
                    Next
                End If
            End If
        End If
        Return textProperties

    End Function

    Public Function ConvertBack(value As Object, targetType As System.Type, parameter As Object, culture As System.Globalization.CultureInfo) As Object Implements System.Windows.Data.IValueConverter.ConvertBack
        Throw New NotSupportedException()
    End Function

End Class

Public Class DisplayNameConverter
    Implements IValueConverter

    Public Function Convert(value As Object, targetType As System.Type, parameter As Object, culture As System.Globalization.CultureInfo) As Object Implements System.Windows.Data.IValueConverter.Convert

        If value IsNot Nothing Then
            Return String.Format(CultureInfo.CurrentCulture, "{0}:", value)
        End If
        Return String.Empty

    End Function

    Public Function ConvertBack(value As Object, targetType As System.Type, parameter As Object, culture As System.Globalization.CultureInfo) As Object Implements System.Windows.Data.IValueConverter.ConvertBack
        Throw New NotSupportedException()
    End Function

End Class

Public Class PropertyNameToDisplayNameConverter
    Implements IValueConverter

    Public Function Convert(value As Object, targetType As System.Type, parameter As Object, culture As System.Globalization.CultureInfo) As Object Implements System.Windows.Data.IValueConverter.Convert

        If TypeOf value Is String AndAlso String.IsNullOrEmpty(DirectCast(value, String)) Then
            Return "<Auto>"
        End If
        Return value

    End Function

    Public Function ConvertBack(value As Object, targetType As System.Type, parameter As Object, culture As System.Globalization.CultureInfo) As Object Implements System.Windows.Data.IValueConverter.ConvertBack
        Throw New NotSupportedException()
    End Function

End Class

