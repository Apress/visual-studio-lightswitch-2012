﻿Imports System
Imports System.Collections.Generic
Imports System.Diagnostics
Imports System.Linq
Imports Microsoft.LightSwitch.Model

Public Module ModelUtilities
    ''' <summary>
    ''' GetUnderlyingSystemType is a helper function to extract which CLR type is used to represent data of a LightSwitch simple type.
    ''' </summary>
    ''' <param name="dataType">LightSwitch DataType</param>
    ''' <returns>CLR type used to reprsent the data</returns>
    Public Function GetUnderlyingSystemType(dataType As ISimpleType) As Type

        If dataType Is Nothing Then
            Throw New ArgumentNullException("dataType")
        End If

        While dataType IsNot Nothing
            If TypeOf dataType Is IPrimitiveType Then
                ' Primitive types are foundation LightSwitch data types like: String/Int32/Decimal/Date/...
                '  This is a set that cannot be extended by a third party.
                Return DirectCast(dataType, IPrimitiveType).ClrType
            ElseIf TypeOf dataType Is INullableType Then
                ' NullableType represents a Nullable version of any primitive or semantic type.
                dataType = DirectCast(dataType, INullableType).UnderlyingType
            ElseIf TypeOf dataType Is ISemanticType Then
                ' Semantic types are types extending primitive types and adding additional semantic information like data format or validation logic.
                dataType = DirectCast(dataType, ISemanticType).UnderlyingType
            Else
                ' This should never happen.  A simple type in LightSwitch is either a semantic type, a nullable type or a primitive type.
                dataType = Nothing
            End If
        End While

        Debug.Assert(False, "We expect all semantic types in the LightSwitch are built on the top of a primitive type.")
        Return Nothing

    End Function

    ''' <summary>
    ''' IsTextProperty returns true if a property can be represented by a string.  
    ''' In LightSwitch, a non-binary simple type property cannot be represented by a string.
    ''' </summary>
    ''' <param name="propertyDefinition">The definition of a property in the LightSwitch metadata</param>
    ''' <returns>true if the property can be represented as a string</returns>
    Public Function IsTextProperty(propertyDefinition As IPropertyDefinition) As Boolean

        If propertyDefinition Is Nothing Then
            Throw New ArgumentException("propertyDefinition")
        End If

        Dim dataType As ISimpleType = TryCast(propertyDefinition.PropertyType, ISimpleType)
        If dataType IsNot Nothing Then
            Dim clrType As Type = GetUnderlyingSystemType(dataType)
            Return clrType IsNot Nothing AndAlso clrType IsNot GetType(Byte())
        End If
        Return False

    End Function

    ''' <summary>
    ''' Get all text presentable properties of a data type.
    ''' </summary>
    ''' <param name="dataType">A data type metadata in the LightSwitch</param>
    ''' <returns>A collection of properties matching the condition.</returns>
    Public Function GetAllSingletonNavigationProperties(dataType As IDataType) As IEnumerable(Of IPropertyDefinition)

        If dataType IsNot Nothing Then
            Return (From p As IEntityPropertyDefinition In dataType.Properties.OfType(Of INavigationPropertyDefinition)()
                                                        Where TypeOf p.PropertyType Is IEntityType Select p).Cast(Of IPropertyDefinition)()
        End If

        Return Enumerable.Empty(Of IPropertyDefinition)()

    End Function

    Public Function GetSourceNavProperty(screenCollectionProperty As IScreenCollectionPropertyDefinition) As INavigationPropertyDefinition

        Dim mappedNavProperty As INavigationPropertyDefinition
        If TypeOf screenCollectionProperty.Query.Source.Body Is IMemberExpressionNode Then
            'tc.SetError("Collection must be bound to a navigation property.")
            Return Nothing
        ElseIf TypeOf screenCollectionProperty.Query.Source.Body Is IChainExpressionNode Then
            Dim chainExp As IChainExpressionNode = screenCollectionProperty.Query.Source.Body
            If Not TypeOf DirectCast(chainExp.Links.Last(), IMemberExpressionNode).Member Is INavigationPropertyDefinition Then
                ' tc.SetError("Collection is not bound to a navigation property.")
                Return Nothing
            End If
            mappedNavProperty = DirectCast(DirectCast(chainExp.Links.Last(), IMemberExpressionNode).Member, INavigationPropertyDefinition)
        Else
            'tc.SetError("Cannot determine the parent collection.")
            Return Nothing
        End If

        ''Ensure that the bound collection has two navigation properties that are singular
        Dim boundEntityType As IEntityType = DirectCast(screenCollectionProperty.PropertyType, ISequenceType).ElementType
        'Dim numScalarNavigationProperties As Int32 = (From p As IEntityPropertyDefinition In boundEntityType.Properties.OfType(Of INavigationPropertyDefinition)()
        '                                            Where TypeOf p.PropertyType Is IEntityType Select p).Count
        'If numScalarNavigationProperties <> 2 Then
        '    'tc.SetError("This control requires two scalar navigation properties on the collection's entity type.")
        '    Return Nothing
        'End If

        Dim sourceNavigationProperty As INavigationPropertyDefinition = (From p As INavigationPropertyDefinition In boundEntityType.Properties.OfType(Of INavigationPropertyDefinition)()
                                       Where p.Association.Name = mappedNavProperty.Association.Name
                                       Select p).SingleOrDefault
        If sourceNavigationProperty Is Nothing Then
            'tc.SetError("Cannot determine the source navigation property for this collection's entity type.")
            Return Nothing
        End If

        Return sourceNavigationProperty
    End Function

    Public Function GetTargetNavProperty(dataType As IDataType, targetNavPropertyName As String, sourceNavProperty As INavigationPropertyDefinition) As INavigationPropertyDefinition
        Dim boundEntityType As IEntityType = dataType
        Dim targetNavProperty As INavigationPropertyDefinition

        If Not String.IsNullOrEmpty(targetNavPropertyName) Then
            'Get it from the model
            targetNavProperty = (From p As INavigationPropertyDefinition In boundEntityType.Properties.OfType(Of INavigationPropertyDefinition)()
                       Where TypeOf p.PropertyType Is IEntityType AndAlso p.Name = targetNavPropertyName).SingleOrDefault
            If targetNavProperty IsNot Nothing Then
                Return targetNavProperty
            End If
        End If

        'Otherwise determine it automatically
        targetNavProperty = (From p As INavigationPropertyDefinition In boundEntityType.Properties.OfType(Of INavigationPropertyDefinition)()
                                       Where TypeOf p.PropertyType Is IEntityType AndAlso p IsNot sourceNavProperty).FirstOrDefault()

        Return targetNavProperty
    End Function

    Public Function GetScreenFromContentItemDefinition(ByVal contentItemDef As IContentItemDefinition) As IScreenDefinition
        Dim currentItem As IContentItemDefinition = contentItemDef

        While TypeOf currentItem.Parent Is IContentItemDefinition
            currentItem = currentItem.Parent
        End While

        If TypeOf currentItem.Parent Is IScreenDefinition Then
            Return currentItem.Parent
        Else
            Return Nothing
        End If

    End Function
End Module
