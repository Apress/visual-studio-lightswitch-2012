﻿Imports Microsoft.LightSwitch.Model
Imports Microsoft.LightSwitch.Details.Client
Imports Microsoft.LightSwitch.Presentation

Module SharedUtilities
    Function GetMappedNavigationProperty(boundCollection As IScreenCollectionProperty) As INavigationPropertyDefinition
        'Try to automatically determine based on the model
        'Get the query's source
        'Eventually expression should point to some member (nav property)
        If TypeOf boundCollection.GetModel.Query.Source.Body Is IMemberExpressionNode Then
            Throw New Exception("Collection must be bound to a navigation property.")
        ElseIf TypeOf boundCollection.GetModel.Query.Source.Body Is IChainExpressionNode Then
            Dim chainExp As IChainExpressionNode = boundCollection.GetModel.Query.Source.Body
            If Not TypeOf DirectCast(chainExp.Links.Last(), IMemberExpressionNode).Member Is INavigationPropertyDefinition Then
                Throw New Exception("Collection is not bound to a navigation property.")
            End If
            Return DirectCast(chainExp.Links.Last(), IMemberExpressionNode).Member
        Else
            Throw New Exception("Cannot determine the parent collection.")
        End If
    End Function

    Function GetSourceNavigationProperty(boundCollection As IScreenCollectionProperty, mappedNavigationProperty As INavigationPropertyDefinition) As INavigationPropertyDefinition
        Dim boundEntityType As IEntityType = DirectCast(boundCollection.GetModel.PropertyType, ISequenceType).ElementType
        Dim sourceNavProperty As INavigationPropertyDefinition = (From p As INavigationPropertyDefinition In boundEntityType.Properties.OfType(Of INavigationPropertyDefinition)()
                                       Where p.Association.Name = mappedNavigationProperty.Association.Name
                                       Select p).SingleOrDefault()
        If sourceNavProperty Is Nothing Then
            Throw New Exception("Cannot determine the source navigation property for this collection's entity type.")
        End If
        Return sourceNavProperty
    End Function

    Function GetChoicesNavigationProperty(boundCollection As IScreenCollectionProperty, ByVal contentItem As IContentItem, ByVal sourceNavigationProperty As INavigationPropertyDefinition)
        Dim boundEntityType As IEntityType = DirectCast(boundCollection.GetModel.PropertyType, ISequenceType).ElementType

        

        Dim choicesNavigationProperty As INavigationPropertyDefinition

        If contentItem.Properties.ContainsKey("ManyToManyControls:BaseManyToManyControl/TargetNavigationProperty") AndAlso Not String.IsNullOrWhiteSpace(contentItem.Properties("ManyToManyControls:BaseManyToManyControl/TargetNavigationProperty")) Then
            Dim targetNavPropertyName As String = contentItem.Properties("ManyToManyControls:BaseManyToManyControl/TargetNavigationProperty")
            If targetNavPropertyName = sourceNavigationProperty.Name Then
                Throw New Exception("Target navigation propety cannot be the same as the source navigation property.")
            End If

            choicesNavigationProperty = (From p As INavigationPropertyDefinition In boundEntityType.Properties.OfType(Of INavigationPropertyDefinition)()
                       Where TypeOf p.PropertyType Is IEntityType AndAlso p.Name = targetNavPropertyName).SingleOrDefault
            If choicesNavigationProperty Is Nothing Then
                Throw New Exception("Cannot find a valid navigation property with the name " + targetNavPropertyName)
            End If
        Else
            'Try determine this automatically
            Dim numScalarNavigationProperties As Int32 = (From p As IEntityPropertyDefinition In boundEntityType.Properties.OfType(Of INavigationPropertyDefinition)()
                                                    Where TypeOf p.PropertyType Is IEntityType Select p).Count
            If numScalarNavigationProperties <> 2 Then
                Throw New Exception("This control requires two scalar navigation properties on the collection's entity type.")
            End If


            choicesNavigationProperty = (From p As INavigationPropertyDefinition In boundEntityType.Properties.OfType(Of INavigationPropertyDefinition)()
                                       Where TypeOf p.PropertyType Is IEntityType AndAlso p IsNot sourceNavigationProperty).SingleOrDefault
            If choicesNavigationProperty Is Nothing Then
                Throw New Exception("Cannot determine the choices navigation property for this collection's entity type.")
            End If
        End If
        Return choicesNavigationProperty
    End Function
End Module
