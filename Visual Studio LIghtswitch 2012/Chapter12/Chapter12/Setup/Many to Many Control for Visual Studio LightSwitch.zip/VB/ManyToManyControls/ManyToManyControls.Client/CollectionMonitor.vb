﻿Imports System.Collections.Specialized
Imports Microsoft.LightSwitch
Imports Microsoft.LightSwitch.Client
Imports Microsoft.LightSwitch.Threading
Imports System.Diagnostics
Imports System.ComponentModel
Imports Microsoft.LightSwitch.Details

Public Class CollectionMonitor(Of TEntityType As IEntityObject)
    Private WithEvents _source As INotifyCollectionChanged
    Private _originalSource As New List(Of IEntityObject)
    Private _itemChangedHandler As Action(Of TEntityType, String)
    Private _itemAddedHandler As Action(Of TEntityType)
    Private _itemRemovedHandler As Action(Of TEntityType)
    Private _screen As IScreenObject
    'Private _monitorDetails As Boolean
    Private _handlerOnUIThread As Boolean


    Public Sub New(ByVal collection As INotifyCollectionChanged, _
                   ByVal itemChangedHandler As Action(Of TEntityType, String), _
                   ByVal itemAddedHandler As Action(Of TEntityType), _
                   ByVal itemRemovedHandler As Action(Of TEntityType), _
                   ByVal screen As IScreenObject,
                   Optional ByVal handlerOnUIThread As Boolean = False)
        _itemChangedHandler = itemChangedHandler
        _itemAddedHandler = itemAddedHandler
        _itemRemovedHandler = itemRemovedHandler
        _screen = screen

        '_monitorDetails = monitorEntityDetails
        _handlerOnUIThread = handlerOnUIThread
        Dispatchers.Main.BeginInvoke(Sub()
                                         _source = collection
                                         ResetList()
                                     End Sub)
    End Sub

    Private Sub AddEntityHandler(ByVal e As IEntityObject)
        _originalSource.Add(e)
        AddHandler DirectCast(e, INotifyPropertyChanged).PropertyChanged, AddressOf EntityChanged
        AddHandler DirectCast(e.Details, INotifyPropertyChanged).PropertyChanged, AddressOf EntityDetailsChanged
    End Sub
    Private Sub RemoveEntityHandler(ByVal e As IEntityObject)
        _originalSource.Remove(e)
        RemoveHandler DirectCast(e, INotifyPropertyChanged).PropertyChanged, AddressOf EntityChanged
        RemoveHandler DirectCast(e.Details, INotifyPropertyChanged).PropertyChanged, AddressOf EntityDetailsChanged
    End Sub

    Private Sub RemoveAllObjects()
        Debug.Assert(Dispatchers.Main.CheckAccess(), "This function should be called from the UI thread")

        For Each e As IEntityObject In _originalSource
            RemoveHandler DirectCast(e, INotifyPropertyChanged).PropertyChanged, AddressOf EntityChanged
            RemoveHandler DirectCast(e.Details, INotifyPropertyChanged).PropertyChanged, AddressOf EntityDetailsChanged

            If _itemRemovedHandler IsNot Nothing Then
                If _handlerOnUIThread Then
                    _itemRemovedHandler(e)
                Else
                    _screen.Details.Dispatcher.BeginInvoke(Sub()
                                                               _itemRemovedHandler(e)
                                                           End Sub)
                End If
            End If
        Next
        _originalSource.Clear()
    End Sub


    Private Sub ResetList()
        Debug.Assert(Dispatchers.Main.CheckAccess(), "This function should be called from the UI thread")

        RemoveAllObjects()

        'Cycle new source and update items/addhandler
        If TypeOf _source Is IVisualCollection Then
            For Each e As TEntityType In DirectCast(_source, IVisualCollection)
                AddObject(e)
            Next
        Else
            For Each e As TEntityType In DirectCast(_source, IEnumerable(Of TEntityType))
                AddObject(e)
            Next
        End If
    End Sub
    Private Sub AddObject(e As IEntityObject)
        Debug.Assert(Dispatchers.Main.CheckAccess(), "This function should be called from the UI thread")
        AddEntityHandler(e)
        If _itemAddedHandler IsNot Nothing Then
            If _handlerOnUIThread Then
                _itemAddedHandler(e)
            Else
                _screen.Details.Dispatcher.BeginInvoke(Sub()
                                                           _itemAddedHandler(e)
                                                       End Sub)
            End If
        End If
    End Sub
    Private Sub RemoveObject(e As IEntityObject)
        Debug.Assert(Dispatchers.Main.CheckAccess(), "This function should be called from the UI thread")
        RemoveEntityHandler(e)
        If _itemRemovedHandler IsNot Nothing Then
            If _handlerOnUIThread Then
                _itemRemovedHandler(e)
            Else
                _screen.Details.Dispatcher.BeginInvoke(Sub()
                                                           _itemRemovedHandler(e)
                                                       End Sub)
            End If
        End If
    End Sub

    Private Sub EntityChanged(sender As Object, e As PropertyChangedEventArgs)

        If _itemChangedHandler IsNot Nothing Then
            If _handlerOnUIThread Then
                _itemChangedHandler(sender, e.PropertyName)
            Else
                _screen.Details.Dispatcher.BeginInvoke(Sub()
                                                           _itemChangedHandler(sender, e.PropertyName)
                                                       End Sub)
            End If

        End If
    End Sub
    Private Sub EntityDetailsChanged(sender As Object, e As PropertyChangedEventArgs)
        If e.PropertyName = "EntityState" Then
            If DirectCast(sender, IEntityDetails).EntityState = EntityState.Deleted Then
                RemoveObject(DirectCast(sender, IEntityDetails).Entity)
            End If
        End If
        If _itemChangedHandler IsNot Nothing Then
            If _handlerOnUIThread Then
                _itemChangedHandler(DirectCast(sender, IEntityDetails).Entity, "Details." + e.PropertyName)
            Else
                _screen.Details.Dispatcher.BeginInvoke(Sub()
                                                           _itemChangedHandler(DirectCast(sender, IEntityDetails).Entity, "Details." + e.PropertyName)
                                                       End Sub)
            End If
        End If
    End Sub

    Private Sub _source_CollectionChanged(sender As Object, e As System.Collections.Specialized.NotifyCollectionChangedEventArgs) Handles _source.CollectionChanged
        'This should be triggered on the UI thread.
        Debug.Assert(Dispatchers.Main.CheckAccess(), "Expected to executed on UI thread.")

        If e.Action = Collections.Specialized.NotifyCollectionChangedAction.Add Then
            For Each i In e.NewItems
                Dim currentEntity As IEntityObject = i
                AddObject(currentEntity)
            Next
        ElseIf e.Action = Collections.Specialized.NotifyCollectionChangedAction.Remove Then
            For Each i In e.OldItems
                Dim currentEntity As IEntityObject = i
                RemoveObject(currentEntity)
            Next
        ElseIf e.Action = Collections.Specialized.NotifyCollectionChangedAction.Replace Then
            For Each i In e.OldItems
                Dim currentEntity As IEntityObject = i
                RemoveObject(currentEntity)
            Next
            For Each i In e.NewItems
                Dim currentEntity As IEntityObject = i
                AddObject(currentEntity)
            Next
        ElseIf e.Action = Collections.Specialized.NotifyCollectionChangedAction.Reset Then
            ResetList()
        End If
    End Sub
End Class