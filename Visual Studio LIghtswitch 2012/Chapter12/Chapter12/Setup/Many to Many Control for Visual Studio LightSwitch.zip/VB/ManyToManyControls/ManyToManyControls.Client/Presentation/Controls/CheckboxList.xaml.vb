Imports System
Imports System.Collections.Generic
Imports System.ComponentModel.Composition
Imports System.IO
Imports System.Linq
Imports System.Net
Imports System.Windows
Imports System.Windows.Controls
Imports System.Windows.Documents
Imports System.Windows.Input
Imports System.Windows.Markup
Imports System.Windows.Media
Imports System.Windows.Media.Animation
Imports System.Windows.Shapes
Imports System.Windows.Resources

Imports Microsoft.LightSwitch.Presentation
Imports Microsoft.LightSwitch.Model
Imports System.Windows.Data
Imports Microsoft.LightSwitch.Details.Client
Imports Microsoft.LightSwitch.Client
Imports Microsoft.LightSwitch
Imports System.Collections.ObjectModel
Imports System.ComponentModel
Imports Microsoft.LightSwitch.Threading
Imports System.Collections.Specialized
Imports Microsoft.LightSwitch.Sdk.Proxy
Imports Microsoft.VisualStudio.ExtensibilityHosting

Namespace Presentation.Controls

    Partial Public Class CheckboxList
        Inherits UserControl

        Private mappedNavigationProperty As INavigationPropertyDefinition
        Private sourceNavigationProperty As INavigationPropertyDefinition
        Private choicesNavigationProperty As INavigationPropertyDefinition
        Private childChoicesNavProperty As INavigationPropertyDefinition
        Private parentChoicesNavProperty As INavigationPropertyDefinition


        Public Sub New()
            InitializeComponent()
            Me.SetBinding(CheckboxList.MyDataContextProperty, New Binding())
        End Sub
        Public Shared ReadOnly MyDataContextProperty As DependencyProperty = _
        DependencyProperty.Register("MyDataContext", GetType(Object), GetType(CheckboxList), _
                                    New PropertyMetadata(Nothing, New PropertyChangedCallback(AddressOf MyDataContextChanged)))

        Private Shared Sub MyDataContextChanged(ByVal d As DependencyObject, ByVal e As DependencyPropertyChangedEventArgs)
            Dim tc As CheckboxList = d
            Dim contentItem As IContentItem = tc.DataContext

            If Not TypeOf contentItem.Value Is IVisualCollection Then
                tc.SetError("This control must be bound to a visual collection.")
                Exit Sub
            End If

            Dim boundCollection As IScreenCollectionProperty = contentItem.Screen.Details.Properties(contentItem.BindingPath)


            'TODO
            'Consider if the nav collection isn't associated with the nav property on some entity
            'Need to allow the user to pick the source nav property and provide some mechanism to set the value of it when an item is added


            Try
                'Try to automatically determine based on the model
                'Get the query's source
                'Eventually expression should point to some member (nav property)
                tc.mappedNavigationProperty = SharedUtilities.GetMappedNavigationProperty(boundCollection)

                'Ensure that the bound collection has two navigation properties that are singular
                'Set the source navigation property
                tc.sourceNavigationProperty = SharedUtilities.GetSourceNavigationProperty(boundCollection, tc.mappedNavigationProperty)

                'Check if the content item has the Target/Choices Nav Property set.  If so, use it.  Otherwise determine automatically
                'Throw error if there are multiple + unset choices
                tc.choicesNavigationProperty = SharedUtilities.GetChoicesNavigationProperty(boundCollection, contentItem, tc.sourceNavigationProperty)

            Catch ex As Exception
                tc.SetError(ex.Message)
                Exit Sub
            End Try
            ''Ensure that the bound collection has two navigation properties that are singular
            ''Set the source navigation property
            'Dim boundEntityType As IEntityType = DirectCast(boundCollection.GetModel.PropertyType, ISequenceType).ElementType
            'Dim numScalarNavigationProperties As Int32 = (From p As IEntityPropertyDefinition In boundEntityType.Properties.OfType(Of INavigationPropertyDefinition)()
            '                                            Where TypeOf p.PropertyType Is IEntityType Select p).Count
            'If numScalarNavigationProperties <> 2 Then
            '    tc.SetError("This control requires two scalar navigation properties on the collection's entity type.")
            '    Exit Sub
            'End If

            'tc.sourceNavigationProperty = (From p As INavigationPropertyDefinition In boundEntityType.Properties.OfType(Of INavigationPropertyDefinition)()
            '                               Where p.Association.Name = tc.mappedNavigationProperty.Association.Name
            '                               Select p).SingleOrDefault
            'If tc.sourceNavigationProperty Is Nothing Then
            '    tc.SetError("Cannot determine the source navigation property for this collection's entity type.")
            '    Exit Sub
            'End If


            ''Check if the content item has the Target Nav Property set.  If so, use it.
            'If contentItem.Properties.ContainsKey("ManyToManyControls:CheckboxList/TargetNavigationProperty") AndAlso Not String.IsNullOrWhiteSpace(contentItem.Properties("ManyToManyControls:CheckboxList/TargetNavigationProperty")) Then
            '    Dim targetNavPropertyName As String = contentItem.Properties("ManyToManyControls:CheckboxList/TargetNavigationProperty")
            '    If targetNavPropertyName = tc.sourceNavigationProperty.Name Then
            '        tc.SetError("Target navigation propety cannot be the same as the source navigation property.")
            '        Exit Sub
            '    End If
            '    tc.choicesNavigationProperty = (From p As INavigationPropertyDefinition In boundEntityType.Properties.OfType(Of INavigationPropertyDefinition)()
            '               Where TypeOf p.PropertyType Is IEntityType AndAlso p.Name = targetNavPropertyName).SingleOrDefault
            '    If tc.choicesNavigationProperty Is Nothing Then
            '        tc.SetError("Cannot find a valid navigation property with the name " + targetNavPropertyName)
            '        Exit Sub
            '    End If
            'Else
            '    tc.choicesNavigationProperty = (From p As INavigationPropertyDefinition In boundEntityType.Properties.OfType(Of INavigationPropertyDefinition)()
            '                               Where TypeOf p.PropertyType Is IEntityType AndAlso p IsNot tc.sourceNavigationProperty).SingleOrDefault
            '    If tc.choicesNavigationProperty Is Nothing Then
            '        tc.SetError("Cannot determine the choices navigation property for this collection's entity type.")
            '        Exit Sub
            '    End If
            'End If


            'Determine if the choices collection is self referencing (and generate an appropriate tree)
            Dim choiceType As IEntityType = tc.choicesNavigationProperty.PropertyType
            Dim numSelfRefNavProperties As Integer = (From p As INavigationPropertyDefinition In choiceType.Properties.OfType(Of INavigationPropertyDefinition)()
                                     Where TypeOf p.PropertyType Is ISequenceType AndAlso DirectCast(p.PropertyType, ISequenceType).ElementType Is choiceType).Count
            If numSelfRefNavProperties > 1 Then
                tc.SetError("Multiple self-referencing relationships found on the choice's type.")
                Exit Sub
            End If
            tc.childChoicesNavProperty = (From p As INavigationPropertyDefinition In choiceType.Properties.OfType(Of INavigationPropertyDefinition)()
                                     Where TypeOf p.PropertyType Is ISequenceType AndAlso DirectCast(p.PropertyType, ISequenceType).ElementType Is choiceType).FirstOrDefault()
            If tc.childChoicesNavProperty IsNot Nothing Then
                tc.parentChoicesNavProperty = (From p As INavigationPropertyDefinition In choiceType.Properties.OfType(Of INavigationPropertyDefinition)()
                                           Where p IsNot tc.childChoicesNavProperty AndAlso p.Association.Name = tc.childChoicesNavProperty.Association.Name).FirstOrDefault()

                If tc.parentChoicesNavProperty Is Nothing Then
                    tc.SetError("Could not find other end of self-referencing relationship.")
                    Exit Sub
                End If

            End If


            Dim cv As ChoicesView
            'Need to determine the query that represents the choices
            'Option 1
            'Look up property setting that specifies it
            If contentItem.Properties.ContainsKey("ManyToManyControls:BaseManyToManyControl/ChoicesCollection") AndAlso Not String.IsNullOrWhiteSpace(contentItem.Properties("ManyToManyControls:BaseManyToManyControl/ChoicesCollection")) Then
                Dim choicesCollectionName As String = contentItem.Properties("ManyToManyControls:BaseManyToManyControl/ChoicesCollection")
                If contentItem.Screen.Details.Properties(choicesCollectionName) Is Nothing OrElse Not TypeOf contentItem.Screen.Details.Properties(choicesCollectionName).Value Is IVisualCollection Then
                    tc.SetError("Cannot find a collection for choices with name " + choicesCollectionName)
                    Exit Sub
                End If


                'Turn off paging for this collection
                Dim screenCollection As IScreenCollectionProperty = contentItem.Screen.Details.Properties(choicesCollectionName)
                screenCollection.Loader.PageSize = 0

                cv = New ChoicesView(contentItem.Screen, _
                                      DirectCast(contentItem.Screen.Details.Properties(choicesCollectionName).Value, INotifyCollectionChanged), _
                                      contentItem.Value, _
                                      GetSummaryProperty(tc.choicesNavigationProperty.PropertyType), _
                                      tc.choicesNavigationProperty,
                                      tc.childChoicesNavProperty,
                                      tc.parentChoicesNavProperty)
            Else
                'Option 2
                'Assume "Auto" and use the entitySet
                'TODO: Need to handle providing the ability to refresh this collection
                'Option 2
                'Assume "Auto" and use the entitySet
                'TODO: Need to handle providing the ability to refresh this collection
                Dim entityContainerDefinition As IEntityContainerDefinition
                Dim serviceProxy As IServiceProxy = VsExportProviderService.GetExportedValue(Of IServiceProxy)()
                Dim moduleWithEntitySets As IModuleDefinition =
                    (From md As IModuleDefinition In serviceProxy.ModelService.Modules
                    Where md.GlobalItems.OfType(Of IEntityContainerDefinition).Any(Function(ecd) ecd.EntitySets.Any(Function(es) es.EntityType Is tc.choicesNavigationProperty.PropertyType))).FirstOrDefault()
                If moduleWithEntitySets IsNot Nothing Then
                    entityContainerDefinition = (From ecd As IEntityContainerDefinition In moduleWithEntitySets.GlobalItems.OfType(Of IEntityContainerDefinition)()
                                                Where ecd.EntitySets.Any(Function(es) es.EntityType Is tc.choicesNavigationProperty.PropertyType)).FirstOrDefault()
                End If
                If entityContainerDefinition Is Nothing Then
                    tc.SetError("Could not find a default query for the choice's type: " + tc.choicesNavigationProperty.PropertyType.Name)
                    Exit Sub
                End If

                Dim entitySetDefinition As IEntitySetDefinition = (From es As IEntitySetDefinition In entityContainerDefinition.EntitySets
                                                                   Where es.EntityType Is tc.choicesNavigationProperty.PropertyType).First

                Dim entitySet As IEntitySet = DirectCast(contentItem.Screen.Details.DataWorkspace.Details.Properties(entityContainerDefinition.Name).Value, IDataService).Details.Properties(entitySetDefinition.Name).Value


                cv = New ChoicesView(contentItem.Screen, _
                                          entitySet, _
                                          contentItem.Value, _
                                          GetSummaryProperty(tc.choicesNavigationProperty.PropertyType), _
                                          tc.choicesNavigationProperty,
                                          tc.childChoicesNavProperty,
                                          tc.parentChoicesNavProperty)
            End If


            'TODO
            'Provide a pager if the bound collection supports paging

            If tc.childChoicesNavProperty IsNot Nothing Then
                tc.checkedTreeView.Visibility = Windows.Visibility.Visible
                tc.simpleCheckBoxes.Visibility = Windows.Visibility.Collapsed
                tc.checkedTreeView.ItemsSource = cv.View
                tc.simpleCheckBoxes.ItemsSource = Nothing
            Else
                tc.checkedTreeView.Visibility = Windows.Visibility.Collapsed
                tc.simpleCheckBoxes.Visibility = Windows.Visibility.Visible
                tc.checkedTreeView.ItemsSource = Nothing
                tc.simpleCheckBoxes.ItemsSource = cv.View
            End If

        End Sub

        Private Sub SetError(p1 As String)
            Me.checkedTreeView.Visibility = Windows.Visibility.Collapsed
            Me.simpleCheckBoxes.Visibility = Windows.Visibility.Collapsed
            Me.errorLabel.Visibility = Windows.Visibility.Visible
            Me.errorLabel.Text = "Error: " + p1
        End Sub

        Private Shared Function GetSummaryProperty(ByVal entityType As IEntityType) As IEntityPropertyDefinition
            Dim attribuate As ISummaryPropertyAttribute = entityType.Attributes.OfType(Of ISummaryPropertyAttribute).FirstOrDefault()
            'If none is specified, try infer one 
            Dim properties As IEnumerable(Of IEntityPropertyDefinition) = entityType.Properties.Where(Function(p) (Not TypeOf p Is INavigationPropertyDefinitionBase) AndAlso (Not p.PropertyType.Name.Contains("Binary")))
            Dim stringProperty As IEntityPropertyDefinition = properties.FirstOrDefault(Function(p) p.PropertyType.Name.Contains("String"))
            If stringProperty Is Nothing Then
                Return properties.FirstOrDefault
            Else
                Return stringProperty
            End If
        End Function



    End Class


    Public Class ChoicesView
        Private _choicesMonitor As CollectionMonitor(Of IEntityObject)
        Private _navCollectionMonitor As CollectionMonitor(Of IEntityObject)
        Private _choicesCollection As INotifyCollectionChanged
        Private _navCollection As IVisualCollection
        Private _screen As IScreenObject
        Private _summaryProperty As IEntityPropertyDefinition
        Private _choiceNavProperty As INavigationPropertyDefinition
        Private _childChoicesNavProperty As INavigationPropertyDefinition
        Private _parentChoicesNavProperty As INavigationPropertyDefinition



        Public Property View As New ObservableCollection(Of SelectableEntity)

        Public Sub New(ByVal screen As IScreenObject, _
                       ByVal choices As INotifyCollectionChanged, _
                       ByVal navCollection As IVisualCollection, _
                       ByVal summaryProperty As IEntityPropertyDefinition, _
                       ByVal choiceNavProperty As INavigationPropertyDefinition, _
                       ByVal childChoicesNavProperty As INavigationPropertyDefinition, _
                       ByVal parentChoicesNavProperty As INavigationPropertyDefinition)

            _screen = screen
            _summaryProperty = summaryProperty
            _choiceNavProperty = choiceNavProperty
            _navCollection = navCollection
            _childChoicesNavProperty = childChoicesNavProperty
            _parentChoicesNavProperty = parentChoicesNavProperty

            _choicesCollection = choices



            _choicesMonitor = New CollectionMonitor(Of IEntityObject)(_choicesCollection, _
                                                                      Nothing, _
                                                                      AddressOf ChoiceAdded, _
                                                                      AddressOf ChoiceRemoved,
                                                                      _screen, _
                                                                      handlerOnUIThread:=True)

            _navCollectionMonitor = New CollectionMonitor(Of IEntityObject)(_navCollection, _
                                                                      AddressOf ItemChanged, _
                                                                      AddressOf ItemAdded, _
                                                                      AddressOf ItemRemoved,
                                                                      _screen, _
                                                                      handlerOnUIThread:=True)
        End Sub

        Public Sub New(ByVal screen As IScreenObject, _
                       ByVal choices As IEntitySet, _
                       ByVal navCollection As IVisualCollection, _
                       ByVal summaryProperty As IEntityPropertyDefinition, _
                       ByVal choiceNavProperty As INavigationPropertyDefinition, _
                       ByVal childChoicesNavProperty As INavigationPropertyDefinition, _
                       ByVal parentChoicesNavProperty As INavigationPropertyDefinition)

            _screen = screen
            _summaryProperty = summaryProperty
            _choiceNavProperty = choiceNavProperty
            _navCollection = navCollection
            _childChoicesNavProperty = childChoicesNavProperty
            _parentChoicesNavProperty = parentChoicesNavProperty

            'Need to generate choices from the entity set
            GenerateChoices(choices)

            _choicesMonitor = New CollectionMonitor(Of IEntityObject)(_choicesCollection, _
                                                                      Nothing, _
                                                                      AddressOf ChoiceAdded, _
                                                                      AddressOf ChoiceRemoved,
                                                                      _screen, _
                                                                      handlerOnUIThread:=True)

            _navCollectionMonitor = New CollectionMonitor(Of IEntityObject)(_navCollection, _
                                                                      AddressOf ItemChanged, _
                                                                      AddressOf ItemAdded, _
                                                                      AddressOf ItemRemoved,
                                                                      _screen, _
                                                                      handlerOnUIThread:=True)



        End Sub

        Private Sub GenerateChoices(ByVal choices As IEntitySet)
            _choicesCollection = New ObservableCollection(Of IEntityObject)
            _screen.Details.Dispatcher.BeginInvoke(Sub()
                                                       For Each e As IEntityObject In choices
                                                           Dim currentEntity As IEntityObject = e

                                                           'Only want to show the "top" level items here
                                                           If _parentChoicesNavProperty Is Nothing OrElse ( _
                                                              _parentChoicesNavProperty IsNot Nothing AndAlso _
                                                              currentEntity.Details.Properties(_parentChoicesNavProperty.Name).Value Is Nothing) Then
                                                               Microsoft.LightSwitch.Threading.Dispatchers.Main.BeginInvoke(Sub()
                                                                                                                                DirectCast(_choicesCollection, ObservableCollection(Of IEntityObject)).Add(currentEntity)
                                                                                                                            End Sub)
                                                           End If


                                                       Next
                                                   End Sub)
        End Sub

#Region "Add/Remove/Changed Methods for Choices"
        Private Sub ChoiceAdded(ByVal e As IEntityObject)
            Dim isSelected As Boolean = _navCollection.OfType(Of IEntityObject).Any(Function(eo) eo.Details.Properties(_choiceNavProperty.Name).Value Is e)
            View.Add(New SelectableEntity(isSelected, e, Me))
        End Sub

        Private Sub ChoiceRemoved(ByVal e As IEntityObject)
            Dim choiceItem As SelectableEntity = View.Where(Function(se) se.Entity Is e).SingleOrDefault()
            If choiceItem IsNot Nothing Then
                View.Remove(choiceItem)
            End If
        End Sub

        'Private Sub ChoiceChanged(ByVal e As IEntityObject, ByVal propertyName As String)
        '    If propertyName = _summaryProperty.Name Then
        '        Dim choiceItem As SelectableEntity = View.Where(Function(se) se.Entity Is e).SingleOrDefault()
        '        If choiceItem IsNot Nothing Then
        '            choiceItem.Text = e.Details.Properties(_summaryProperty.Name).Value
        '        End If
        '    End If
        'End Sub
#End Region

#Region "Add/Remove/Changed Methods for Nav Collection"
        Private Sub ItemAdded(ByVal e As IEntityObject)
            Dim matchedSelectableItem As SelectableEntity = FindSelectedableItem(e, View)
            If matchedSelectableItem IsNot Nothing Then
                matchedSelectableItem.SetIsSelected(True)
            End If
        End Sub

        Private Sub ItemRemoved(ByVal e As IEntityObject)
            Dim matchedSelectableItem As SelectableEntity = FindSelectedableItem(e, View)
            If matchedSelectableItem IsNot Nothing Then
                matchedSelectableItem.SetIsSelected(False)
            End If
        End Sub

        Private Sub ItemChanged(ByVal e As IEntityObject, ByVal propertyName As String)
            If propertyName = _choiceNavProperty.Name Then
                For Each si As SelectableEntity In View
                    si.SetIsSelected(False)
                Next
                For Each n As IEntityObject In _navCollection
                    ItemAdded(n)
                Next
            End If
        End Sub

        Private Function FindSelectedableItem(ByVal navEntity As IEntityObject, ByVal collection As IEnumerable(Of SelectableEntity)) As SelectableEntity
            'Nested Search :S
            Dim matchedSelectableItem As SelectableEntity = collection.Where(Function(s) s.Entity Is navEntity.Details.Properties(_choiceNavProperty.Name).Value).FirstOrDefault()
            If matchedSelectableItem IsNot Nothing Then
                Return matchedSelectableItem
            End If

            For Each s As SelectableEntity In collection
                matchedSelectableItem = FindSelectedableItem(navEntity, s.Children)
                If matchedSelectableItem IsNot Nothing Then
                    Return matchedSelectableItem
                End If
            Next

            Return Nothing



        End Function
#End Region

#Region "SelectableEntity Class"
        Public Class SelectableEntity
            Implements INotifyPropertyChanged

            'Private _summaryProperty As IEntityPropertyDefinition
            Private _view As ChoicesView

            Public Sub New(ByVal isSelected As Boolean, ByVal choiceEntity As IEntityObject, view As ChoicesView)
                SetIsSelected(isSelected)
                _view = view
                Me.Entity = choiceEntity

                'Need to populate the children
                If _view._childChoicesNavProperty IsNot Nothing Then

                    'Can't iterate the child collection on the UI thread :(
                    _view._screen.Details.Dispatcher.BeginInvoke(
                        Sub()
                            For Each e As IEntityObject In DirectCast(choiceEntity.Details.Properties(_view._childChoicesNavProperty.Name).Value, IEntityCollection)
                                Dim childIsSelected As Boolean = _view._navCollection.OfType(Of IEntityObject).Any(Function(eo) eo.Details.Properties(_view._choiceNavProperty.Name).Value Is e)
                                Dim currentChild As IEntityObject = e
                                Dispatchers.Main.BeginInvoke(Sub()
                                                                 Children.Add(New SelectableEntity(childIsSelected, currentChild, _view))
                                                             End Sub)

                            Next
                        End Sub)
                End If

            End Sub

            Public Property Children As New ObservableCollection(Of SelectableEntity)

#Region "IsSelected"
            Private _isSelected As Boolean
            Public Property IsSelected As Boolean
                Get
                    Return _isSelected
                End Get
                Set(value As Boolean)
                    If _isSelected = False AndAlso value = True Then
                        'Switch from false to true
                        'Add an item
                        _view._screen.Details.Dispatcher.BeginInvoke(Sub()
                                                                         Dim newEntity As IEntityObject = _view._navCollection.AddNew()
                                                                         newEntity.Details.Properties(_view._choiceNavProperty.Name).Value = Me.Entity
                                                                     End Sub)


                    ElseIf _isSelected = True AndAlso value = False Then
                        'Remove an item
                        For Each existingItem As IEntityObject In _view._navCollection.OfType(Of IEntityObject).Where(
                                Function(e) e.Details.Properties(_view._choiceNavProperty.Name).Value Is Me.Entity)
                            Dim currentExistingItem As IEntityObject = existingItem
                            _view._screen.Details.Dispatcher.BeginInvoke(Sub()
                                                                             currentExistingItem.Delete()
                                                                         End Sub)
                        Next
                    End If
                End Set
            End Property

            'The IsSelected property is used from the UI to modify the value
            'SetIsSelected is used internally by the ChoicesView class when responding to items added
            'to the nav collection
            Friend Sub SetIsSelected(ByVal value As Boolean)
                _isSelected = value
                RaisePropertyChanged("IsSelected")
            End Sub
#End Region
#Region "Text Property"
            Private _text As String
            Public Property Text As String
                Get
                    Return _text
                End Get
                Set(value As String)
                    _text = value
                    RaisePropertyChanged("Text")
                End Set
            End Property

            Private Sub UpdateText()
                Me.Text = DirectCast(_entity, IEntityObject).Details.Properties(_view._summaryProperty.Name).Value.ToString
            End Sub

#End Region
#Region "Choice Entity Property"
            Private WithEvents _entity As INotifyPropertyChanged
            Public Property Entity As IEntityObject
                Get
                    Return _entity
                End Get
                Set(value As IEntityObject)
                    _entity = value
                    UpdateText()
                    RaisePropertyChanged("Entity")
                End Set
            End Property

            Private Sub _entity_PropertyChanged(sender As Object, e As System.ComponentModel.PropertyChangedEventArgs) Handles _entity.PropertyChanged
                If e.PropertyName = _view._summaryProperty.Name Then
                    UpdateText()
                End If
            End Sub
#End Region

#Region "INotifyPropertyChanged"
            Public Event PropertyChanged(sender As Object, e As System.ComponentModel.PropertyChangedEventArgs) Implements System.ComponentModel.INotifyPropertyChanged.PropertyChanged
            Private Sub RaisePropertyChanged(ByVal propertyName As String)
                RaiseEvent PropertyChanged(Me, New PropertyChangedEventArgs(propertyName))
            End Sub
#End Region
        End Class
#End Region

    End Class

    <Export(GetType(IControlFactory))>
    <ControlFactory("ManyToManyControls:CheckboxList")>
    Friend Class CheckboxListFactory
        Implements IControlFactory

#Region "IControlFactory Members"

        Public ReadOnly Property DataTemplate As DataTemplate Implements IControlFactory.DataTemplate
            Get
                If Me.cachedDataTemplate Is Nothing Then
                    Me.cachedDataTemplate = TryCast(XamlReader.Load(CheckboxListFactory.ControlTemplate), DataTemplate)
                End If
                Return Me.cachedDataTemplate
            End Get
        End Property

        Public Function GetDisplayModeDataTemplate(ByVal contentItem As IContentItem) As DataTemplate Implements IControlFactory.GetDisplayModeDataTemplate
            Return Nothing
        End Function

#End Region

#Region "Private Fields"

        Private cachedDataTemplate As DataTemplate

#End Region

#Region "Constants"

        Private Const ControlTemplate As String =
            "<DataTemplate" & _
            " xmlns=""http://schemas.microsoft.com/winfx/2006/xaml/presentation""" & _
            " xmlns:x=""http://schemas.microsoft.com/winfx/2006/xaml""" & _
            " xmlns:ctl=""clr-namespace:ManyToManyControls.Presentation.Controls;assembly=ManyToManyControls.Client"">" & _
            "<ctl:CheckboxList/>" & _
            "</DataTemplate>"

#End Region

    End Class

End Namespace